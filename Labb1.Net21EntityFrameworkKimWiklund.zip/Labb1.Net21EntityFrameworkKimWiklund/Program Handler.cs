﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Labb1.Net21EntityFrameworkKimWiklund
{
    class Program_Handler
    {
        internal void Run()
        {
            bool run = true;
            Console.WriteLine(".......Welcome, This is the Start of the application.......\n" +
                              "Press enter to continue");
            Console.ReadLine();
            while (run)
            {
                string[] firstMenu = new string[] { "Admin Menu", "Employee Menu", "Quit" };
                int userChoice = MenuAndResultUserChoice(firstMenu, "Choices: ");
                switch (userChoice)
                {
                    case 1:
                        RunAdminMenu();
                        break;
                    case 2:
                        RunEmployeeMenu();
                        break;
                    case 3:
                        Console.WriteLine("..................\n Terminating, press enter to close.......");
                        Console.ReadLine();
                        run = false;
                        break;
                }
            }
        }


        private void PrintTitleScreen()
        {
            Console.WriteLine("---- TITLE SCREEN ----\n" +
                              "Pick One\n" +
                              "[1] Apply for Leave\n" +
                              "[2] History\n" +
                              "[0} Quit");
        }




        public int RunEmployeeMenu()
        {
            Console.WriteLine("Who Are you? (Options : 1-7)\n" +
                              "1: Amanda Westman\n" +
                              "2: Sebastian Skalare\n" +
                              "3: Kim Wiklund\n" +
                              "4: Pelle Westman\n" +
                              "5: Sara Bodin\n" +
                              "6: Helene Andersson\n" +
                              "7: Linnea Häggkvist\n");

            int employeeInput = Convert.ToInt32(Console.ReadLine());
            return employeeInput;
        }

        public static int MenuAndResultUserChoice(string[] firstMenuChoices, string menuHeader)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine(menuHeader);
                for (int i = 0; i < firstMenuChoices.Length; i++)
                {
                    Console.WriteLine($"{i + 1}, {firstMenuChoices[i]}");
                }
                Console.WriteLine("Type in your choice of option then enter: ");

                string userInput = Console.ReadLine();
                bool isInt = int.TryParse(userInput, out int choice);
                if (isInt && choice < firstMenuChoices.Length + 1 && choice > 0)
                {
                    return choice;
                }
                else
                {
                    Console.WriteLine(".............................\n Error, please press enter to try again...");
                    Console.ReadLine();
                }


            }
        }
    }
}
