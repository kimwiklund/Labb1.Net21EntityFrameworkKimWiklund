﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Labb1.Net21EntityFrameworkKimWiklund.Models
{
    class Reasons
    {
        [Key]
        public int ReasonId { get; set; }
        [Required]
        public string Reason { get; set; }

        public static List<Reasons> GetReason()
        {
            return new List<Reasons>()
            {
                new Reasons{ReasonId = 1,Reason = "Sick"},
                new Reasons{ReasonId = 2,Reason = "Vab"},
                new Reasons{ReasonId = 3,Reason = "Vacation"},
                new Reasons{ReasonId = 4,Reason = "Unpaid"},

            };
        }

    }
}
