﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Labb1.Net21EntityFrameworkKimWiklund.Models
{
    class LabbDBContext : DbContext
    {

        public DbSet<Employees> Employees { get; set; }
        public DbSet<Dates> Dates { get; set; }
        public DbSet<Reasons> Reasons { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source = DESKTOP-FARI6OS\\SQLEXPRESS;Initial Catalog=Labb1;Integrated Security = True;");
        }

        

    }
}

