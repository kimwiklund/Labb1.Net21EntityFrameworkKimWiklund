﻿using Labb1.Net21EntityFrameworkKimWiklund.Models;
using System;


namespace Labb1.Net21EntityFrameworkKimWiklund
{
    class Program
    {
        static void Main(string[] args)
        {
            LabbDBContext context = new LabbDBContext();
            context.Run();
            
            


        }

    }
}
